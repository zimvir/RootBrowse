"""MCP 使用指南"""

MCP_GUIDE = """# RootBrowseMCP 使用指南

## 初始化
1. init_browser(headless=True) — 初始化浏览器（必须先调用）
   - headless=True: 无头模式（默认）
   - headless=False: 有头浏览器

## 基本工作流
init_browser() → get_page(url) → get_page_regions() → match_element(...) → get_element(ref) → click_element(ref)

## 工具列表

### 浏览器
- init_browser(headless) — 初始化浏览器
- get_page(url, timeout) — 打开URL
- take_screenshot(path) — 截图
- close_browser() — 关闭浏览器

### 页面扫描
- get_page_regions() — 获取页面区域列表
- get_region_summary(region_id) — 获取区域统计摘要
- match_element(region_id, tag, role, text_contains, query, limit) — 按条件筛选元素
- get_element(ref) — 获取元素完整信息

### 元素操作
- click_element(ref) — 点击元素
- input_text(ref, text, clear) — 向输入框输入文字
- send_enter() — 发送回车

### 标签页
- new_tab(url) — 打开新标签页
- close_tab() — 关闭当前标签页
- switch_tab(index) — 切换标签页
- get_tabs_count() — 获取标签页数量

### 状态
- save_state(path) — 保存浏览器状态（cookies）
- load_state(path) — 恢复浏览器状态

## 数据类型

### Region（区域）
{id, label, root_xpath}

### Element（元素）
{ref, tag, role, text, xpath, attrs}

### ElementPreview（元素摘要）
{ref, text, attrs_preview}

### OperationResult（操作结果）
{success, error?, new_url?}
"""